package dao;

import pojos.User;

public interface UserDao {
//register new user
	String registerUser(User newUser);
}
