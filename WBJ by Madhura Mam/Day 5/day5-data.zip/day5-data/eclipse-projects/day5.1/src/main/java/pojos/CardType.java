package pojos;

public enum CardType {
CREDIT_CARD,DEBIT_CARD,FOREX
}
