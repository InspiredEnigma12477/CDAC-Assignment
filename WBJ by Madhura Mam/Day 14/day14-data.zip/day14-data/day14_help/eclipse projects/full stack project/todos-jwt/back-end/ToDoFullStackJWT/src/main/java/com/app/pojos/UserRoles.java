package com.app.pojos;

public enum UserRoles {
	ROLE_USER, ROLE_ADMIN,ROLE_STUDENT
}
