import React from 'react';

export default function LogOutComponent() {
  return (
    <>
      <h1>You have logged out...</h1>
      <div className='container'>Thanks for visiting</div>
    </>
  );
}
