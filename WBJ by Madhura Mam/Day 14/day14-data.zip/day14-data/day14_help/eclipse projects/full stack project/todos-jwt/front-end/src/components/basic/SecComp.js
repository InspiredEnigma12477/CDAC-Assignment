import React, { Component } from 'react';

export class SecComp extends Component {
  render() {
    return (
      <div>
        <h3>Second Component</h3>
      </div>
    );
  }
}
