import React from 'react';

export default function ErrorComponent() {
  return (
    <div>
      <h4>Some Error occurred.....</h4>
    </div>
  );
}
