package com.app.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exception.ResourceNotFoundException;
import com.app.dto.OrderDTO;
import com.app.dto.OrderRespDto;
import com.app.entities.Order;
import com.app.entities.Product;
import com.app.entities.UserEntity;
import com.app.entity.projection.OrderItem;
import com.app.repository.OrderRepository;
import com.app.repository.ProductRepository;
import com.app.repository.UserRepository;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {
	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private ProductRepository productRepo;
	
	@Autowired
	private ModelMapper mapper;
	

	@Override
	public OrderRespDto placeOrder(OrderDTO order) {
		// get user proxy (no select query : better performance) from user id
		//a good use case of proxy
		UserEntity user = userRepo.getReferenceById(order.getUserId());
		//get product proxy from product id
		Product product = productRepo.getReferenceById(order.getProductId());
		Order newOrder = new Order();
		newOrder.setPrice(order.getPrice());
		newOrder.setUser(user);
		newOrder.setProduct(product);
		Order savedOrder = orderRepository.save(newOrder);
		return mapper.map(savedOrder, OrderRespDto.class);
	}

	@Override
	public List<OrderItem> findPurchaseItemsOfUser(String email) {
		return orderRepository.findAllPurchaseItemsByUserEmail(email);
	}
}
