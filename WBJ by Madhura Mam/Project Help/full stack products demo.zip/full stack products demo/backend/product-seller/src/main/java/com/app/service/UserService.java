package com.app.service;

import com.app.entities.Role;
import com.app.entities.UserEntity;

public interface UserService {
 UserEntity addUserDetails(UserEntity user);
 //boolean userExists(String email);

	void changeRole(Role role, String email);
}
