package com.app.service;

import java.util.List;

import com.app.dto.OrderDTO;
import com.app.dto.OrderRespDto;
import com.app.entity.projection.OrderItem;


public interface OrderService
{
    OrderRespDto placeOrder(OrderDTO order);

    List<OrderItem> findPurchaseItemsOfUser(String email);
}
