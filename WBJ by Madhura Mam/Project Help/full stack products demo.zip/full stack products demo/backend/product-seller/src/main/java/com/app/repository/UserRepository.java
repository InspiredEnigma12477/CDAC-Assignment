package com.app.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.app.entities.Role;
import com.app.entities.UserEntity;


public interface UserRepository extends JpaRepository<UserEntity, Long>
{
    //findBy + fieldName
    Optional<UserEntity> findByEmail(String email);
    boolean existsByEmail(String email);

    @Modifying
    @Query("update UserEntity u  set u.role = ?1 where u.email = ?2")
    void updateUserRole(Role role,String email);
}
