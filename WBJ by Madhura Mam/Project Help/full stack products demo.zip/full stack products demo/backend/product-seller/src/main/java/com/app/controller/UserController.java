package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.entities.Role;
import com.app.service.CustomUserDetails;
import com.app.service.UserService;


@RestController
@RequestMapping("/users")//pre-path
public class UserController
{
    @Autowired
    private UserService userService;

    @PutMapping("change/{role}")//api/user/change/{role}
    public ResponseEntity<?> changeRole(@AuthenticationPrincipal CustomUserDetails userDetails, @PathVariable Role role)
    {
    	System.out.println("in change role "+role+" "+userDetails.getAuthorities());
        userService.changeRole(role, userDetails.getUsername());

        return ResponseEntity.ok(true);
    }
}
