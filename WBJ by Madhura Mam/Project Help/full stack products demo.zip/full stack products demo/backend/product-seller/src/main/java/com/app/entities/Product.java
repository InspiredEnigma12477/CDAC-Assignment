package com.app.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "products")
public class Product extends BaseEntity
{   

    @Column(nullable = false,unique = true)
    private String name;

    @Column( nullable = false)
    private String description;

    @Column( nullable = false)
    private double price;

    @Column(nullable = false)
    @CreationTimestamp
    private LocalDateTime createTime;
    
    private String imagePath;

	public Product(String name, String description, double price) {
		super();
		this.name = name;
		this.description = description;
		this.price = price;
	}
    
    

    //@OneToMany(fetch = FetchType.LAZY, mappedBy = "product")
    //private Set<Purchase> purchaseList;
}
