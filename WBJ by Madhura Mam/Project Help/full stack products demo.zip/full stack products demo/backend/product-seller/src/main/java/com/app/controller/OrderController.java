package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.OrderDTO;
import com.app.entities.Order;
import com.app.service.CustomUserDetails;
import com.app.service.OrderService;



@RestController
@RequestMapping("/orders") //pre-path
public class OrderController
{
    @Autowired
    private OrderService orderService;


    @PostMapping 
    public ResponseEntity<?> placeOrder(@RequestBody OrderDTO order)
    {
    	System.out.println("in place order "+order);
        return new ResponseEntity<>(orderService.placeOrder(order), HttpStatus.CREATED);
    }

    @GetMapping //api/purchase
    public ResponseEntity<?> getAllPurchaseItemsOfUser(@AuthenticationPrincipal CustomUserDetails user)
    {
    	System.out.println("user "+user.getUsername()+" "+user.getPassword()+" "+user.getAuthorities());
        return ResponseEntity.ok(orderService.findPurchaseItemsOfUser(user.getUsername()));//actually it's email
    }
}
