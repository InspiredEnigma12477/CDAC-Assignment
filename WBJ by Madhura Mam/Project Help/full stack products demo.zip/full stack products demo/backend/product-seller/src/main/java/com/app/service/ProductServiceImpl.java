package com.app.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exception.ResourceNotFoundException;
import com.app.entities.Product;
import com.app.repository.OrderRepository;
import com.app.repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductRepository productRepo;
	@Autowired
	private OrderRepository orderRepo;

	@Override
	public Product saveProduct(Product product) {

		return productRepo.save(product);
	}

	@Override
	public void deleteProduct(Long id) {
		// validate if product exists
		if (productRepo.existsById(id)) {
			// delete the child recs (orders) first n then delete the product
			System.out.println("deleted " + orderRepo.deleteByProductId(id) + " orders");
			productRepo.deleteById(id);
		} else
			throw new ResourceNotFoundException("Invalid Product ID , Can't delete the product!!!");
	}

	@Override
	public List<Product> findAllProducts() {
		return productRepo.findAll();
	}
}
