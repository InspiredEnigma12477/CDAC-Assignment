package com.app.service;

import java.util.List;

import com.app.entities.Product;


public interface ProductService
{
    Product saveProduct(Product product);

    void deleteProduct(Long id);

    List<Product> findAllProducts();
}
