package com.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.entities.Order;
import com.app.entity.projection.OrderItem;


public interface OrderRepository extends JpaRepository<Order, Long>
{
//    @Query("select " +
//            "prd.name as name, pur.price as price, pur.purchaseTime as purchaseTime " +
//            "from Purchase pur left join Product prd on prd.id = pur.productId " +
//            "where pur.userId = :userId")
//    List<PurchaseItem> findAllPurchasesOfUser(@Param("userId") Long userId);
	//@Query("select name,price,purchaseTime from Purchase p join p.user u where u.email=?1")
	@Query("select new com.app.entity.projection.OrderItem(p.name as name,o.price as price,o.purchaseTime as purchaseTime) from Order o join o.user u join o.product p where u.email=?1")
	List<OrderItem> findAllPurchaseItemsByUserEmail(String email);
	//delete all orders by specific productId
	long deleteByProductId(long productId);
}
