import { useEffect, useState } from 'react';
import ProductService from '../../services/product.service';
import PurchaseService from '../../services/purchase.service';
import { useSelector } from 'react-redux';
import Purchase from '../../models/purchase';
import './home.page.css';
// import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
// import { faCartPlus } from '@fortawesome/free-solid-svg-icons';
// import axios from 'axios';

const HomePage = () => {

    const [productList, setProductList] = useState([]);
    const [errorMessage, setErrorMessage] = useState('');
    const [infoMessage, setInfoMessage] = useState('');
    
    const [pics, setPics] = useState({});

    const currentUser = useSelector(state => state.user);
  //  const fixedImg="http://localhost:8080/products/1/image"
    const BASE_URL="http://localhost:8080/products/";
    // const showImage=(product)=>{
    //     console.log("in show image "+product.id);
    //     ProductService.getProductImage(product.id).
    //     then((res) =>
    //      {
    //          product.url=URL.createObjectURL(res.data);
    //  //   console.log("url "+product.url);        
    //     setPics(URL.createObjectURL(res.data));
    //    // console.log("pics "+pics);
    // }
    //      ).
    //     catch((err) => console.log("err "+err));        
             
    // }



    useEffect(() => {
        console.log("use effect1");
        ProductService.getAllProducts().then((response) => {
            setProductList(response.data);

        });
        
        
    }, 
    []);
    // useEffect(() => {
    //     console.log("use effect2");
    //     console.log("pr list1 "+productList);
    //     productList.forEach(product =>{             
    //         showImage(product);
    //     });
    // },[productList]);

    const purchase = (product) => {
        if (!currentUser?.id) {
            setErrorMessage('You should login to buy a product.');
            return;
        }

        const purchase = new Purchase(currentUser.id, product.id, product.price);

        PurchaseService.savePurchase(purchase).then(() => {
            setInfoMessage('Product Purchased.');
        }).catch((err) => {
            setErrorMessage('Unexpected error occurred.');
            console.log(err);
        });
    };

    return (
        <div className="container p-3">

            {errorMessage &&
            <div className="alert alert-danger">
                {errorMessage}
            </div>
            }

            {infoMessage &&
            <div className="alert alert-success">
                {infoMessage}
            </div>
            }

            <div className="d-flex flex-wrap">
                {productList.map((item, ind) =>
                    <div key={item.id} className="card m-3 home-card">

                        <div className="card-body">
                            <div className="card-title text-uppercase">{item.name}</div>
                            <div className="card-subtitle text-muted">{item.description}</div>
                            {/* <img src={item.url} style={{'height':'100px','width':'100px'}}></img> */}
                            {/* <img src={fixedImg} style={{'height':'100px','width':'100px'}}></img>
                         */}
                         <img src={BASE_URL +item.id +'/image'} style={{'height':'100px','width':'100px'}} alt="No Image!!!"></img>
                         </div>
                         {/* <div className="card-body media align-items-center" style={{ marginLeft: "70vh" }}>

                             <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="No Image!!!" className="img-fluid rounded border shadow" style={{ marginLeft: "18vh", width: "20vh", height: "15vh" }} />
 </div> */}

                        {/* <FontAwesomeIcon icon={faCartPlus} className="ms-auto me-auto product-icon"/> */}

                        <div className="row mt-2 p-3">
                            <div className="col-6 mt-2 ps-4">
                                {`Rs. ${item.price}`}
                            </div>
                            <div className="col-6">
                                <button
                                    className="btn btn-outline-success w-100" onClick={() => purchase(item)}>
                                    Buy
                                </button>
                            </div>
                        </div>

                    </div>
                )}

            </div>

        </div>
    );
};

export {HomePage};
