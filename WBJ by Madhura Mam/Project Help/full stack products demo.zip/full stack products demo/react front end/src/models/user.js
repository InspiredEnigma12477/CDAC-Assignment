export default class User {
  constructor(email, password, firstName, lastName, role, token, id) {
    this.email = email;
    this.password = password;
    this.firstName = firstName;
    this.lastName = lastName;
    this.role = role;
    this.token = token;
    this.id = id;
  }
}
