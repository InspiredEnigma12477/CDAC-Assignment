export const Role = {
  USER: 'ROLE_CUSTOMER',
  ADMIN: 'ROLE_ADMIN',
};
