export default class Product {
  constructor(name, description, price, createTime, id) {
    this.name = name;
    this.description = description;
    this.price = price;
    this.createTime = createTime;
    this.id = id;
    //  this.url = url;
  }
}
