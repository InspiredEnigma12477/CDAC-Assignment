Full stack demo containing
1. E-R (between Product n Orders n Users)
Refer : Order entity
2. Usage of DTOs
3. Spring security using JWT based authentication n authorization
4. Image upload n download.
5. Global exc handling , validations , swagger , model mapper ...
6. Interceptors n auth routes in front end
7. Redux store n state management , reducers hooks
....


You can un comment TestUserService to create admin n customer . 
OR you can use Sign Up option from the front end.
Hope this helps.
Good Luck!