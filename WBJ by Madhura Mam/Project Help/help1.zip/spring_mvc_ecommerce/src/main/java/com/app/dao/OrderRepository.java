package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Order;
import com.app.pojos.Status;

public interface OrderRepository extends JpaRepository<Order, Long> {
	//search for the top order , placed by a specific customer , whose order status = ENTERED(NEW) 
	Optional<Order> findTop1ByCustomerIdAndOrderStatus(long userId,Status status);
}
