package com.app.pojos;

public enum Status {
	ENTERED, PLACED, SHIPPED, DELIVERED, CANCELLED, PAYMENT_FAILED
}
