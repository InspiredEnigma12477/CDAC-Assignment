package com.app.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Role;
import com.app.pojos.User;
import com.app.service.UserService;

@Controller // mandatory !
@RequestMapping("/user")
public class UserController {
	// Dependency
	// Controller --dependent upon Service layer : for B.L

	@Autowired // autowire=byType
	private UserService userService;

	public UserController() {
		System.out.println("in ctor of " + getClass());
	}

//add req handling method for rendering login form
	@GetMapping("/login") // =@RequestMapping (method=GET)
	public String showLoginForm() {
		System.out.println("in show login form");
		return "/user/login";// LVN --> D.S --> V.R : AVN : /WEB-INF/views/user/login.jsp
	}

	// add req hanling method to process login form
	@PostMapping("/login") // =@RequestMapping (method=POST)
	// how many rq params ? 2 : email n pass
	// @RequestParam : anno to bind req params --> method args
	// @RequestParam(name="pass") String pass123 : SC --> String
	// pass123=request.getParamter("pass");
	public String processLoginForm(@RequestParam String email, @RequestParam String pass, Model map,
			HttpSession session,RedirectAttributes flashMap) {
		System.out.println("in process login form " + email + " " + pass);
		try {
			// handler --> service --> dao : JPQL --> DB --> results
			User validatedUser = userService.authenticateUser(email, pass);
			flashMap.addFlashAttribute("mesg", "Login Successful!!!!");//mesg will be retained till NEXT req from the same clnt
			session.setAttribute("user_dtls", validatedUser);//dtls will be retained till invalidate/sess expires
			// role based authorization
			if (validatedUser.getRole() == Role.ADMIN) // => admin login
				return "redirect:/admin/categories";
			System.out.println("user details "+validatedUser);
			System.out.println("cart "+validatedUser.getMyCart());
			return "redirect:/customer/details";// skips V.R n view layer

		} catch (RuntimeException e) {
			e.printStackTrace();
			System.out.println("err in process login form " + e);
			// => invalid login ---> forward the clnt to login page
			map.addAttribute("mesg", "Invalid Login!!!!!!!!!!!!!!!!!!!"); //curnt req only !
			return "/user/login";// AVN : /WEB-INF/views/user/login.jsp

		}

	}
	// add a method to logout admin / customer
		@GetMapping("/logout")
		public String logout(HttpServletRequest request, HttpServletResponse resp, Model map, HttpSession session) {
			System.out.println("in user logout");
			// place user details in req scope (model map)
			map.addAttribute("details", session.getAttribute("user_dtls"));
			// invalidate Http Session
			session.invalidate();
			// set refresh header to auto navigate the clnt to index page after a slight
			// delay
			resp.setHeader("refresh", "5;url=" + request.getContextPath());// ctx path : /day14.1_boot
			return "/user/logout";// AVN : /WEB-INF/views/user/logout.jsp
		}

		// add a method to show reg form to the user
		@GetMapping("/register")
		public String showRegForm(Model map) {
			System.out.println("in show reg form");
			// bind empty POJO to the model map
			map.addAttribute("new_user", new User());// model --> view layer
			return "/user/register";// AVN : /WEB-INF/views/user/register.jsp
		}

		// add a method to process reg form
		@PostMapping("/register")
		public String processRegForm(@ModelAttribute(name = "new_user") User transientUser, Model map, HttpSession session,
				HttpServletRequest request, HttpServletResponse resp) {
			System.out.println("In process reg form " + transientUser);
			// invoke service layer's method for persistence n add the mesg to req scope
			map.addAttribute("mesg", userService.addUserDetails(transientUser));
			resp.setHeader("refresh", "5;url="+request.getContextPath());
			session.invalidate();
			return "/user/registered";//AVN : /WEB-INF/views/user/registered.jsp
		}


}
