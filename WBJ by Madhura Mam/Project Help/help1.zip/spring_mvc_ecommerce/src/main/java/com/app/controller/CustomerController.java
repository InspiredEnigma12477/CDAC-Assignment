package com.app.controller;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.dao.CategoryDao;
import com.app.dao.ProductDao;
import com.app.pojos.Order;
import com.app.pojos.ShoppingCart;
import com.app.pojos.Status;
import com.app.pojos.User;
import com.app.service.OrderService;
import com.app.service.ShoppingCartService;

@Controller
@RequestMapping("/customer")
public class CustomerController {
	// dep : DAO i/f : category dao
	@Autowired
	private CategoryDao categoryDao;
	// dep : Product dao
	@Autowired
	private ProductDao productDao;

	@Autowired
	private ShoppingCartService cartService;

	@Autowired
	private OrderService orderService;

	@Value("${payment_gateway}")
	private String paymentGatewayLink;

	public CustomerController() {
		System.out.println("in ctor of " + getClass());
	}

	// add req handling method to forward the clnt to details page
	@GetMapping("/details")
	public String getDetails(Model map, HttpSession session) {
		System.out.println("in get categories");
		long userId = ((User) session.getAttribute("user_dtls")).getId();
		// get cart details
		map.addAttribute("total_cart_items", cartService.getTotalCartItems(userId));
		// how to send categories to clnt ?
		// invoke dao's method --> List --> scope ?
		map.addAttribute("all_categories", categoryDao.getAllCategories());
		return "/customer/details";// AVN : /WEB-INF/views/customer/details.jsp
	}

	// add req handling method to get all products under the chosen category
	@GetMapping("/products")
	public String getProducts(@RequestParam long catId, Model map) {
		System.out.println("in get products...");
		map.addAttribute("selected_products", productDao.findByProductCategoryId(catId));
		return "/customer/products";
	}

	// add request handling method to get product details
	@GetMapping("product_details")
	public String getProductDetails(@RequestParam long pid, Model map) {
		System.out.println("in get product dtls " + pid);
		map.addAttribute("product_details", productDao.findById(pid).orElseThrow());
		return "/customer/product_details";
	}

	// add request handling method to add a product to the cart
	@PostMapping("/add_to_cart")
	public String addToCart(@RequestParam int quantity, @RequestParam long prodId, HttpSession session,
			RedirectAttributes flashMap) {
		System.out.println("in add to cart " + quantity + " " + prodId);
		long userId = ((User) session.getAttribute("user_dtls")).getId();
		cartService.addProductToCart(userId, prodId, quantity);
		return "redirect:/customer/details";

	}

	// add a req handling method to show the cart contents n payment link
	@GetMapping("/show_cart")
	public String showCartContents(HttpSession session, Model map) {
		System.out.println("in show cart ");
		// invoke service layer method to get cart contents
		long userId = ((User) session.getAttribute("user_dtls")).getId();
		// get cart details
		map.addAttribute("cart", cartService.getCartDetails(userId));
		return "/customer/show_cart";
	}

	// add a request handling method to make a call to dummy payment service (REST
	// call): RestTemplate
	// Create another API : for payment OR redirect user to payment gateway : I
	// think this will be better
	// may be with refresh header set : with a delay n a mesg ! try it !
	@GetMapping("/check_out")
	public String redirectToPaymentGateway(HttpSession session, RedirectAttributes flashMap,HttpServletResponse resp) {
		// add cart content --> order (add order items etc....)
		// 1. invoke service layer method to get cart contents
		long userId = ((User) session.getAttribute("user_dtls")).getId();
		// get cart details
		ShoppingCart cart = cartService.getCartDetails(userId);
		//transfer cart items to --> order  
		Order placeOrder = orderService.placeOrder(cart);
		//save the current order id in HttpSession : for further reference
		session.setAttribute("order_id", placeOrder.getId());//new logic
		System.out.println("in redirect to payment");
		
	//	return "redirect:" + paymentGatewayLink +(placeOrder.getTotalPrice()+placeOrder.getShippingFee());
		resp.setHeader("refresh", "5;url="+paymentGatewayLink+(placeOrder.getTotalPrice()+placeOrder.getShippingFee()));
		return "/customer/payment_continue";
	}

	// add a method after a payment gateway redirects the clnt back to our online
	// shopping web site
	// where u chk the tx --if successful -- empty the cart ,change the order status
	@GetMapping("/payment_status/{status}")
	public String checkPaymentStatus(HttpSession session,  @PathVariable boolean status, RedirectAttributes flashMap) {
		System.out.println("in chk payment sts " + status);
	
		long orderId=(Long)session.getAttribute("order_id");
			String orderStatus = orderService.completeOrder(orderId, status);
			flashMap.addFlashAttribute("mesg",orderStatus);					
		//in case of the failed tx : we are not emptying the cart contents, so that user can retry again.
	//	flashMap.addFlashAttribute("status", status);
		return "redirect:/customer/details";
	}

}
