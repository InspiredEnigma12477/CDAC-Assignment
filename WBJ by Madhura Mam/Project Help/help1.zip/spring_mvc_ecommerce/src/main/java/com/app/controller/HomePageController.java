package com.app.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller // Mandatory : to tell SC : req handling controller --handler : spring bean
			// ---singleton ,eager
public class HomePageController {
	public HomePageController() {
		System.out.println("in ctor of " + getClass());
	}

	// add req handling method to render index page --changing timestamp
	@RequestMapping("/")
	public String renderIndexPage(Model map) {
		System.out.println("in render index page " + map);// {}
		// populate model map with server TS
		map.addAttribute("server_ts", new Date());
		return "/index";// Handler ---> LVN ---> D.S ---> V.R --> AVN (/WEB-INF/views/index.jsp) --> D.S
		// chk for model attrs : yes -- stores model attr /s under request scope -->
		// forwards the clnt --> view layer
	}

}
