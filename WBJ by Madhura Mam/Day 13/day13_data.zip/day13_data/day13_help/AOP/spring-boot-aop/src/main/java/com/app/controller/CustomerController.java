package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/customer")
public class CustomerController {
	
	

	// add request handling method to get all topics n share it with the view layer
	@GetMapping("/customer_details")
	public String showAllTopics(Model map) {
		System.out.println("in cust details");
		
		return "/customer/customer_details";
	}

}
