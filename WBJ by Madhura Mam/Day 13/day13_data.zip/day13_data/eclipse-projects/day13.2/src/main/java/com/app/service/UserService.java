package com.app.service;

import com.app.entities.UserEntity;

public interface UserService {
	UserEntity addUserDetails(UserEntity user);
}
