package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entities.UserEntity;
import com.app.repository.UserRepository;

@Service
@Transactional
public class CustomUserDetailsService implements UserDetailsService {
	// dep : User Repo
	@Autowired
	private UserRepository userRepo;
//This method will be auto invoked by spring sec : DaoAuthProvider
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		// get user details from DB by user name
		UserEntity user = userRepo.findByEmail(email)
				.orElseThrow(() -> new UsernameNotFoundException("Invalid Email!!!!!!!!!!"));
		//=> email verifed --now simply ret user details lifted form DB to the caller
		return new CustomUserDetails(user);
	}

}
