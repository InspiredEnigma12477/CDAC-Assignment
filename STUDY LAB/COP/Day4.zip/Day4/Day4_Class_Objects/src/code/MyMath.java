package code;

public class MyMath {
	
	public void show()
	{
		System.out.println("public method");
	}
	
	public void  show(String str)
	{System.out.println("show method");
		System.out.println("welcome "+str);
	}
public void  show(String str,int no)
{
	System.out.println("show method");
	
}
}
