package code;

class ImpClass {

}
