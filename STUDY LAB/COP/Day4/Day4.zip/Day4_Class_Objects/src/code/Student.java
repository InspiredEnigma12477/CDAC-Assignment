package code;

public class Student {

}
