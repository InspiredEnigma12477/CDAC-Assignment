package tester;

import code.Date;

public class TestParaConstr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Date d=new Date(3, 5, 1998);//parameterised
		d.printDate();
	}

}
