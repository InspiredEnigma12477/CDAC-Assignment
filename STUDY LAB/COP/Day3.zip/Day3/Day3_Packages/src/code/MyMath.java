package code;

public class MyMath {

	
	public void display()
	{
		System.out.println("display");
	}
	
}
