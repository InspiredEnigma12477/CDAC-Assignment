package mathoperations;

public class MyMath {

	public void publicFunction() {
		System.out.println("----public method----");
	}

	private void privateFunction() {
		System.out.println("----private method----");
	}

	// default access specifer
	void defaultFunction() {
		System.out.println("----default method----");
	}

	protected void protectedFunction() {
		System.out.println("----protected method----");
	}
}
