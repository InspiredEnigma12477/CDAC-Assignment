
public class TestCommandLine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      
		//int a= Integer.parseInt(args[0]);
		
		System.out.println("Length="+args.length);
		for(int i=0;i<args.length;i++)
		{
			System.out.println(args[i]);
			
		}
	}

}
