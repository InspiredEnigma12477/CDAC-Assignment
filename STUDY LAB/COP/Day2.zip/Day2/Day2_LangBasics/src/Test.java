
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=10,b=9090;
		long l=a+b;//
		char c='A';
		int s=c;
		System.out.println(c);
		System.out.println(s);
		
		int x=(int) l;
		
	}

}
