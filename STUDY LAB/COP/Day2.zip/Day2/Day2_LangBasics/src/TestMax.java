
public class TestMax {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=10,b=3;
		
		if(a>b)
			System.out.println("Max="+a);
		else
			System.out.println("Max="+b);
		
		System.out.println("--------------------");
		int c=(a>b?a:b);
		System.out.println("Max="+c);
		
	}

}
