package code;
//this is package level class:access specifier is default
 class MyImpclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
