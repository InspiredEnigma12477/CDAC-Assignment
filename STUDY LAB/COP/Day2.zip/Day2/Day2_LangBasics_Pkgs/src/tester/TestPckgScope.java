package tester;

import code.TestArray;


public class TestPckgScope {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TestArray arr;
		
	}

}
