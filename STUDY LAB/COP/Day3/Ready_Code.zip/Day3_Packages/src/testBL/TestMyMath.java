package testBL;



public class TestMyMath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		//MyMath m=new MyMath();
		//m.display();
		
		
		mathoperations.MyMath m1=new mathoperations.MyMath();
		m1.publicFunction();
		code.MyMath cm=new  code.MyMath();
		cm.display();
		
	}

}
