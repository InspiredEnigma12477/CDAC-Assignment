package mathoperations;

class ImpClass {

	public void impMethod()
	{
		System.out.println("in default class");
	}
}
