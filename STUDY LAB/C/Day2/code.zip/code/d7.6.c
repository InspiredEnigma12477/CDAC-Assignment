#include<stdio.h>
//int main()
//{
	//int marks[5],i;
	//int marks[]={10,20,30,40,50,60},i;
	/*for(i=0;i<5;i++)
	{
		printf("Enter the element%d\n",i);//accept value
		//scanf("%d",&marks[i]);
		scanf("%d",marks+i);
	}*/
/*	for(i=0;i<5;i++)
	{
		//printf("Marks is %d subject=%d\n",i,marks[i]);
		printf("Marks is %d subject=%d\n",i,*(marks+i));
	}
	printf("Sizeof array=%d",sizeof(marks));//4*size of array5
	printf(" Starting Address of array=%u\n",marks);
	printf("Base Address of array=%u\n",&marks[0]);
	printf("Base Address of array=%u",marks+0);
	
	return 0;
	
}*/

