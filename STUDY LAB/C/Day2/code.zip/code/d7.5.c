#include<stdio.h>
int main()
{
	register int i;
	printf("%d\n",i);
}
