//pattern example------------------------
#include<stdio.h>
/*int main()
{
	int i,j;
	for(i=1;i<=5;i++)
	{
		for(j=1;j<=i;j++)
		{
			printf("%d",j);
		}
		printf("\n");
		
	}
	return 0;
}*/
/*int main()
{
	int i,j;
	for(i=1;i<=5;i++)  //i=1 j=1     
	{
		for(j=1;j<=i;j++)
		{
			printf("%d",i);
		}
		printf("\n");
		
	}
	return 0;
}*/
//--------------star(*)pattern example-----------------------
/*int main()
{
	int i,j;
	for(i=1;i<=5;i++)  //i=1 j=1     
	{ //j=1;
	//while(j<=1)
	for(j=1;j<=i;j++)
		{
			printf("*");
		}
		printf("\n");
		
	}
	return 0;
}*/

