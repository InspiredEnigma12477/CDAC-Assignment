int main()
{
	int num;
	printf("enter the number");
	scanf("%d",&num);
}
