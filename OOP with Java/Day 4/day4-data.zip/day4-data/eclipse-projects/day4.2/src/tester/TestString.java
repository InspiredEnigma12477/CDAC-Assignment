package tester;

public class TestString {

	public static void main(String[] args) {
		String s1=new String("Hello !");
		String s2=s1.concat("Lunch Break !!!!");
		System.out.println(s1);
		System.out.println(s2);

	}

}
