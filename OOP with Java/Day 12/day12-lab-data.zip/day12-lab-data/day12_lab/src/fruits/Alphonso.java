package fruits;

public class Alphonso extends Mango {

	@Override
	public String taste() {
		// TODO Auto-generated method stub
		return "very sweet";
	}
	//pulp
	public void pulp()
	{
		System.out.println("making pulp of Alphonso!");
	}

}
