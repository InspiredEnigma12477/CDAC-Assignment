package fruits;

public class Orange extends Fruit {

	@Override
	public String taste() {
		// TODO Auto-generated method stub
		return "sour for "+this;
	}

}
