package fruits;

public class Fruit {
	public String taste() {
		return "NO specific taste!!!!!";
	}
}
