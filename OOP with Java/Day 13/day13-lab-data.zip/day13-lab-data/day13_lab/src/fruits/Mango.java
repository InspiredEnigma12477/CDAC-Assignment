package fruits;

public class Mango extends Fruit {

	@Override
	public String taste() {
		// TODO Auto-generated method stub
		return "sweet";
	}

}
