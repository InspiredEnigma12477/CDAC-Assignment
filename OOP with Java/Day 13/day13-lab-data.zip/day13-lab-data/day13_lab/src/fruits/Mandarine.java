package fruits;

public class Mandarine extends Orange {

	@Override
	public String taste() {
		// TODO Auto-generated method stub
		return "sweet n sour";
	}
	//juice
	public void juice()
	{
		System.out.println("Extracting Mandarine juice!");
	}

}
