package com.app.core;

public enum Category {
	SCIENCE, TECHNOLOGY, PROGRAMMING, FICTION, YOGA
}
