package custom_exception;

public class LibraryHandlingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LibraryHandlingException(String mesg) {
		super(mesg);
	}
}
