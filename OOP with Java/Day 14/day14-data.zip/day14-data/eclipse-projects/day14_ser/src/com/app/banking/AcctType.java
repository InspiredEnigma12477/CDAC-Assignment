package com.app.banking;

public enum AcctType {
	SAVINGS, CURRENT, FD, LOAN, DMAT
}
