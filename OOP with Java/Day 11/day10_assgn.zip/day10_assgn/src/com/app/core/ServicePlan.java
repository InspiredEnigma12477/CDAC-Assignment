package com.app.core;

public enum ServicePlan {
	SILVER,GOLD,DIAMOND,PLATINUM
}
