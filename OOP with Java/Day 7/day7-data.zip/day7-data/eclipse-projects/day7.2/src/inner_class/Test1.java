package inner_class;

public class Test1 {

	public static void main(String[] args) {
		// add java code below to invoke outer's static method

		// add java code below to invoke outer's non-static method

		// add java code below to invoke inner's non-static method

	}

}
