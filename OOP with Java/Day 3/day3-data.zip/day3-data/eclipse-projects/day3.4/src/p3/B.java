package p3;

public interface B {
	
	void show(String mesg);
}
