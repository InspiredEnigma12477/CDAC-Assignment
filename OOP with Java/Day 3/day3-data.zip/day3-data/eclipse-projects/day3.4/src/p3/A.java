package p3;

public interface A {

	void show();
}
