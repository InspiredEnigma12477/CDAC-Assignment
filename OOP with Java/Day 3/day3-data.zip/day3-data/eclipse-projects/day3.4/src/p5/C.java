package p5;

public interface C extends A, B {
	void print(String mesg);
}
