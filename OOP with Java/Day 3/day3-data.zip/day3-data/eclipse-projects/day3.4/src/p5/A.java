package p5;

public interface A {
	boolean isPrime(int number);
}
