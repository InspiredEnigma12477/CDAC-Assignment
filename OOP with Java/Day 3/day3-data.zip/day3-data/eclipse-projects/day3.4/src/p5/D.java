package p5;

public class D implements C{

	@Override
	public boolean isPrime(int number) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void show(String mesg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double calc(double d1, double d2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void print(String mesg) {
		// TODO Auto-generated method stub
		
	}

}
