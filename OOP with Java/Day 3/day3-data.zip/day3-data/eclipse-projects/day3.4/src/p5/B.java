package p5;

public interface B {
	void show(String mesg);
	double calc(double d1,double d2);
	
}
