package p1;

public class Test1 {

	public static void main(String[] args) {
		//direct referencing
		ConsolePrinter consolePrinter=new ConsolePrinter();
		consolePrinter.print("Some mesg!!!!");
		//Can u create fileprinter n network printer

	}

}
