package p2;

public interface B {
	int DATA = 1234;
	void show();
}
