package p2;

public interface A {
	int DATA = 12345;
	void show();
}
