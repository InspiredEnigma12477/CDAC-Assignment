//package p4;

//public class C implements A, B {

//	@Override
//	public void show() {
//		System.out.println(1);
//		
//	}
//	@Override
//	public String show() {
//		System.out.println(2);
//		return "something!";
//		
//	}
	
	
	
	
//}
