package p4;

public interface B {
	
	String show();
}
