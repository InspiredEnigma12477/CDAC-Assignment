package p4;

public interface A {

	void show();
}
