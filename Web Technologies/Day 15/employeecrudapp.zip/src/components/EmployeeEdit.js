const EmployeeEdit=(props)=>{
    return (
        <h1>Employee edit component</h1>
    )

}

export default EmployeeEdit;