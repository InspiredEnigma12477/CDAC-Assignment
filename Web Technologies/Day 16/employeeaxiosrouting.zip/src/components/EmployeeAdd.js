const EmployeeAdd=()=>{
return(
    <h1>in employee add</h1>
)
}
export default EmployeeAdd;