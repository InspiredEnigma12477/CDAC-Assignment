import './Header.css';
const Header=()=>{
  return(
    <div id="mydiv1">
         <h1>Employee management system</h1>
    </div>
  )
}
export default Header;